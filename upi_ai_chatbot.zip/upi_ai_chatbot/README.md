# AskWise AI Chatbot

A ChatGPT-style general AI chatbot with optional web search and source links, powered by Google's Gemini API.

## Requirements
- Node.js 22 or newer
- A Gemini API key from Google AI Studio (https://aistudio.google.com/apikey)

## Run locally
1. Extract the ZIP file.
2. Open a terminal in the extracted `upi_ai_chatbot` folder.
3. Run `npm install`.
4. Copy `.env.example` to a new file named `.env`.
5. Put your own Gemini API key in `.env` as `GEMINI_API_KEY=...`. Never paste your key into `public/index.html` or share it publicly.
6. Run `npm start`.
7. Open http://localhost:3000 in your browser.

## Configuration (`.env`)
- `GEMINI_API_KEY` — your Google AI Studio API key (required)
- `GEMINI_MODEL` — Gemini model id (default: `gemini-2.5-flash`)
- `PORT` — server port (default: `3000`)

## Features
- General-purpose conversational AI and follow-up context during the current chat
- Optional Google Search grounding with source links
- Responsive chat interface
- UPI safety guidance

## Important
This project needs an API key and internet access. API usage may cost money. It does not include a key in source code; the key stays in the server-side `.env` file. Do not deploy publicly without adding rate limits, authentication, and other abuse protections. If `gemini-3.5-flash` is unavailable to your key, set `GEMINI_MODEL` to another Gemini model enabled for your account. Web search uses free sources (Wikipedia + Google News) so it works without a billed key. The "Search the web" toggle researches the question and cites source links.
