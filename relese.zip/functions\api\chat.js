// Cloudflare Pages Function: handles /api/chat
export async function onRequestPost(context) {
  const { request, env } = context;
  const corsHeaders = { "Content-Type": "application/json" };

  try {
    if (!env.GEMINI_API_KEY) {
      return new Response(JSON.stringify({ error: "Server setup is incomplete: set GEMINI_API_KEY in Cloudflare Pages environment variables." }), { status: 500, headers: corsHeaders });
    }

    let body;
    try { body = await request.json(); } catch { body = {}; }
    const messages = Array.isArray(body.messages) ? body.messages : [];
    if (!messages.length) {
      return new Response(JSON.stringify({ error: "Please enter a message." }), { status: 400, headers: corsHeaders });
    }

    const input = messages.slice(-24).filter(m =>
      ["user", "assistant"].includes(m?.role) && typeof m?.content === "string"
    ).map(m => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content.slice(0, 6000) }]
    }));
    if (!input.length) {
      return new Response(JSON.stringify({ error: "Please enter a message." }), { status: 400, headers: corsHeaders });
    }

    const model = env.GEMINI_MODEL || "gemini-3.5-flash";
    const baseInstructions = `You are AskWise AI, a helpful general-purpose assistant. Answer questions naturally, clearly, and with useful detail. Handle follow-up questions using the conversation history. When web search results are provided, research the question using them and include source links/citations. Be transparent about uncertainty and never invent sources. If asked about UPI or financial fraud, give cautious safety guidance; never ask for PINs, OTPs, passwords, or full banking details. You are not a bank and cannot verify transactions.`;

    const useSearch = Boolean(body.webSearch);
    const lastUserText = [...input].reverse().find(m => m.role === "user")?.parts?.[0]?.text || "";

    // ---------- Free web search ----------
    const STOP_WORDS = new Set(["what","is","the","a","an","of","in","to","for","and","or","how","why","when","where","who","which","do","does","did","can","could","would","should","are","was","were","be","been","being","i","you","he","she","it","we","they","this","that","these","those","with","on","at","by","from","as","about","into","like","than","then","so","if","but","not","no","yes"]);
    function keywords(q) { return q.toLowerCase().split(/[^a-z0-9]+/).filter(w => w.length > 2 && !STOP_WORDS.has(w)); }
    function isRelevant(r, kws) { if (!kws.length) return true; const hay = (r.title + " " + r.snippet).toLowerCase(); const matched = kws.filter(k => hay.includes(k)).length; const need = Math.min(2, kws.length); return matched >= need; }

    async function wikiSearch(query) {
      const url = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&srlimit=5&format=json&origin=*`;
      const res = await fetch(url);
      if (!res.ok) return [];
      const data = await res.json();
      const hits = data?.query?.search || [];
      const out = [];
      for (const h of hits) {
        const title = h.title;
        const pageUrl = `https://en.wikipedia.org/wiki/${encodeURIComponent(title.replace(/ /g, "_"))}`;
        const snippet = (h.snippet || "").replace(/<[^>]+>/g, "");
        out.push({ title, url: pageUrl, snippet });
      }
      for (const r of out) {
        try {
          const t = r.title;
          const exRes = await fetch(`https://en.wikipedia.org/w/api.php?action=query&prop=extracts&exintro=1&explaintext=1&titles=${encodeURIComponent(t)}&format=json&origin=*`);
          const exJson = await exRes.json();
          const pages = exJson?.query?.pages || {};
          const page = Object.values(pages)[0];
          if (page?.extract) r.snippet = page.extract.slice(0, 400);
        } catch {}
      }
      return out;
    }

    async function googleNewsSearch(query) {
      const url = `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=en-US&gl=US&ceid=US:en`;
      const res = await fetch(url);
      if (!res.ok) return [];
      const xml = await res.text();
      const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)];
      const out = [];
      for (const m of items.slice(0, 6)) {
        const block = m[1];
        const title = (block.match(/<title><!\[CDATA\[(.*?)\]\]><\/title>/) || block.match(/<title>(.*?)<\/title>/))?.[1] || "";
        const link = (block.match(/<link>(.*?)<\/link>/))?.[1] || "";
        const desc = (block.match(/<description><!\[CDATA\[(.*?)\]\]><\/description>/) || block.match(/<description>(.*?)<\/description>/))?.[1] || "";
        const cleanDesc = desc.replace(/<[^>]+>/g, "").slice(0, 300);
        if (title && link) out.push({ title: title.trim(), url: link.trim(), snippet: cleanDesc });
      }
      return out;
    }

    async function freeWebSearch(query) {
      const isNews = /\b(news|latest|recent|current|today|breaking)\b/i.test(query);
      const kws = keywords(query);
      const results = [];
      if (isNews) {
        try { results.push(...await googleNewsSearch(query)); } catch {}
      }
      try {
        const wikiQuery = kws.length ? kws.join(" ") : query;
        const wiki = await wikiSearch(wikiQuery);
        for (const r of wiki) {
          if (isRelevant(r, kws)) results.push(r);
        }
      } catch {}
      const seen = new Set();
      const deduped = [];
      for (const r of results) {
        if (r.url && !seen.has(r.url)) { seen.add(r.url); deduped.push(r); }
      }
      return deduped.slice(0, 8);
    }

    // ---------- Generate answer ----------
    let response;
    let usedSearch = false;
    let sources = [];

    if (useSearch) {
      let searchResults = [];
      try { searchResults = await freeWebSearch(lastUserText); } catch { searchResults = []; }
      if (searchResults.length) {
        const context = searchResults.map((r, i) => `[${i + 1}] ${r.title}\nURL: ${r.url}\n${r.snippet}`).join("\n\n");
        const sys = `${baseInstructions}\n\nWeb search results (use these to answer and cite the URLs):\n${context}`;
        response = await geminiGenerate(env.GEMINI_API_KEY, model, input, sys);
        usedSearch = true;
        sources = searchResults.map(r => ({ title: r.title, url: r.url }));
      } else {
        response = await geminiGenerate(env.GEMINI_API_KEY, model, input, baseInstructions);
        usedSearch = false;
      }
    } else {
      response = await geminiGenerate(env.GEMINI_API_KEY, model, input, baseInstructions);
    }

    let answer = (typeof response.text === "function" ? response.text() : response.text) || "Sorry, I couldn't generate an answer.";

    if (sources.length && !answer.includes(sources[0].url)) {
      answer += "\n\nSources:\n" + sources.map(s => `- [${s.title}](${s.url})`).join("\n");
    }
    if (useSearch && !usedSearch) {
      answer += "\n\n_(Live web search returned no results; this answer is from the model's own knowledge.)_";
    }

    return new Response(JSON.stringify({ answer }), { status: 200, headers: corsHeaders });
  } catch (err) {
    console.error("Chat request failed:", err?.message || err);
    const detail = String(err?.message || err);
    const rejected = /api[_ ]?key|401|403|invalid|permission_denied|API_KEY/i.test(detail);
    return new Response(JSON.stringify({
      error: rejected
        ? "The Gemini API key was rejected. Check GEMINI_API_KEY in Cloudflare Pages environment variables."
        : "AI request failed. Check your API key, model name, and internet connection."
    }), { status: rejected ? 502 : 500, headers: corsHeaders });
  }
}

async function geminiGenerate(apiKey, model, input, systemInstruction) {
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: input,
      systemInstruction: { parts: [{ text: systemInstruction }] },
      generationConfig: {}
    })
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`Gemini API ${res.status}: ${txt}`);
  }
  const data = await res.json();
  // Normalize to an object with .text like the SDK
  const text = data?.candidates?.[0]?.content?.parts?.map(p => p.text).filter(Boolean).join("") || "";
  return { text, candidates: data?.candidates };
}

// Handle non-POST gracefully
export async function onRequest(context) {
  if (context.request.method === "POST") return onRequestPost(context);
  return new Response("Method not allowed", { status: 405 });
}
